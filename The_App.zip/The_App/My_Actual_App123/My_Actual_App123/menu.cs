﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Actual_App123
{
    public partial class menu1 : Form
    {
        public menu1()
        {
            InitializeComponent();
        }

        public menu1()
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

            dashboard dash = new dashboard() { TopLevel = false, TopMost = true };
            dash.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(dash);
            dash.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Terms_And_Conditions terms = new Terms_And_Conditions() { TopLevel = false, TopMost = true };
            terms.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(terms);
            terms.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Password_Generator pass = new Password_Generator() { TopLevel = false, TopMost = true };
            pass.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(pass);
            pass.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            ContactSupport Contact = new ContactSupport() { TopLevel = false, TopMost = true };
            Contact.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(Contact);
            Contact.Show();
        }

        private void Username_Label_Click(object sender, EventArgs e)
        {

        }

        private void menu_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
